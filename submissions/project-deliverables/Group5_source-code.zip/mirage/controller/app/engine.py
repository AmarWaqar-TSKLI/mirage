"""Turns raw decoy events into labelled, stored events, attacker state, alerts, and active responses."""

from typing import Optional
from mirage_common import Event, Registry, TrailStage

from .labels import label
from .response_engine import ResponseEngine
from .risk import calculate_risk_score, evaluate_playbook
from .store import Store

STAGE_SEVERITY = {
    TrailStage.ROBOTS_TXT: "medium",
    TrailStage.ENV_BACKUP: "medium",
    TrailStage.SSH_LOGIN: "high",
    TrailStage.AWS_CREDS_READ: "high",
    TrailStage.S3_ACCESS: "critical",
    TrailStage.BAIT_DOWNLOAD: "critical",
}


def leaked_by(registry: Registry) -> dict[str, str]:
    """Credential token -> the bait that leaks it.

    A credential is planted inside an earlier bait: the SSH password inside the
    backup .env, the AWS key inside ~/.aws/credentials. In the registry they share
    a `planted_at`, and the bait has the lower stage. Whoever touched that bait
    first is the one who stole the credential.
    """
    tokens = list(registry)
    return {t.id: b.id for t in tokens for b in tokens
            if b.id != t.id and b.planted_at == t.planted_at and b.stage < t.stage}


class Engine:
    def __init__(self, store: Store, registry: Registry, response_engine: Optional[ResponseEngine] = None):
        self.store = store
        self.registry = registry
        self.response_engine = response_engine
        self.leaked_by = leaked_by(registry)

    def process(self, event: Event) -> tuple[dict, dict | None]:
        """Store the event, update the attacker, trigger responses, and return (event, alert or None)."""
        token = self.registry.get(event.honeytoken_id)
        stage = token.stage if token else TrailStage.NONE
        techniques, engage = label(event, token)
        ip, ts = str(event.src_ip), event.timestamp.isoformat()

        row = {
            "id": str(event.event_id), "ts": ts, "source": str(event.source),
            "event_type": str(event.event_type), "src_ip": ip, "src_port": event.src_port,
            "session_id": event.session_id, "asset": event.asset, "honeytoken_id": event.honeytoken_id,
            "stage": int(stage), "techniques": techniques, "engage": engage, "details": event.details,
        }

        with self.store.lock:
            attacker = self.store.get_attacker(ip)
            first_contact = attacker is None
            attacker = attacker or {
                "ip": ip,
                "first_seen": ts,
                "event_count": 0,
                "max_stage": 0,
                "risk_score": 0,
                "playbook": "watch",
                "contained_at": None,
                "techniques": [],
                "tokens": [],
            }
            new_token = token is not None and token.id not in attacker["tokens"]

            # Same intruder, new address: a stolen credential used from an address
            # other than the one that stole it. The new address inherits the whole
            # intrusion, so switching IPs does not reset the attacker.
            origin = None
            # Only when this address never took that bait itself: two intruders who
            # each found the password on their own are two intruders, not one.
            if (new_token and token.id in self.leaked_by
                    and self.leaked_by[token.id] not in attacker["tokens"]):
                thief = self.store.first_holder(self.leaked_by[token.id])
                if thief and thief != ip and self.store.add_link(ip, thief, token.id, ts):
                    origin = self.store.get_attacker(thief)
            if origin:
                attacker["max_stage"] = max(attacker["max_stage"], origin["max_stage"])
                attacker["techniques"] = list(dict.fromkeys(attacker["techniques"] + origin["techniques"]))
                attacker["tokens"] = list(dict.fromkeys(attacker["tokens"] + origin["tokens"]))

            new_event_count = attacker["event_count"] + 1
            new_max_stage = max(attacker["max_stage"], int(stage))
            new_techniques = list(dict.fromkeys(attacker["techniques"] + techniques))
            new_tokens = list(dict.fromkeys(attacker["tokens"] + [token.id])) if new_token else attacker["tokens"]

            # Dynamic risk score calculation and active response playbook selection
            risk_score = calculate_risk_score(new_max_stage, new_techniques, new_tokens, new_event_count)
            if origin and origin.get("contained_at"):
                # Reusing a contained intruder's stolen credential is the strongest signal there is.
                risk_score = 100
            playbook = evaluate_playbook(risk_score, attacker.get("contained_at") is not None)

            attacker.update(
                last_seen=ts,
                event_count=new_event_count,
                max_stage=new_max_stage,
                risk_score=risk_score,
                playbook=playbook,
                techniques=new_techniques,
                tokens=new_tokens,
            )

            alert = None
            if origin:
                alert = {"severity": "critical",
                         "title": f"Stolen credential reused from a new address: {token.description or token.id}"
                                  f" was taken by {origin['ip']}"}
            elif new_token:
                alert = {"severity": STAGE_SEVERITY.get(stage, "medium"),
                         "title": f"Honeytoken touched: {token.description or token.id} (stage {int(stage)})"}
            elif first_contact:
                alert = {"severity": "low", "title": f"First contact with {event.source} decoy"}
            if alert:
                alert.update(ts=ts, event_id=row["id"], src_ip=ip, honeytoken_id=event.honeytoken_id,
                             stage=int(stage), techniques=techniques, engage=engage)

            self.store.insert_event(row)
            self.store.upsert_attacker(attacker)
            if alert:
                alert = self.store.insert_alert(alert)
            self.store.commit()

        # Orchestrate active response if configured
        if self.response_engine:
            self.response_engine.handle(attacker, row)

        return row, alert
